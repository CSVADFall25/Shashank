// viz/sketch.js  — stroke-face data portrait with index slider

let table;
let frames = [];
let currentIndex = 0;

let faceCX, faceCY, faceR;

let indexSlider = null;
const SLIDER_WIDTH = 420;

// ---------- helpers for safe CSV access ----------

function getStringAny(row, names) {
  if (!Array.isArray(names)) names = [names];
  for (let i = 0; i < names.length; i++) {
    const name = names[i];
    let v;
    try {
      v = row.getString(name);
    } catch (e) {
      v = null;
    }
    if (v !== null && v !== undefined && v !== "" && v !== "NaN") {
      return v;
    }
  }
  return "";
}

function getNumAny(row, names, defaultVal = 0) {
  if (!Array.isArray(names)) names = [names];
  for (let i = 0; i < names.length; i++) {
    const name = names[i];
    let s;
    try {
      s = row.getString(name);
    } catch (e) {
      s = null;
    }
    if (s !== null && s !== undefined && s !== "") {
      const n = parseFloat(s);
      if (!isNaN(n)) return n;
    }
  }
  return defaultVal;
}

// ---------- p5 lifecycle ----------

function preload() {
  table = loadTable("data/facemesh_bio_diet.csv", "csv", "header");
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  colorMode(HSB, 360, 100, 100, 1);
  textFont("Helvetica");
  textSize(13);

  faceCX = width * 0.5;
  faceCY = height * 0.55;
  faceR  = min(width, height) * 0.22;

  buildFrames();
  setupSlider();
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  faceCX = width * 0.5;
  faceCY = height * 0.55;
  faceR  = min(width, height) * 0.22;
  positionSlider();
}

// ---------- slider helpers ----------

function setupSlider() {
  if (!frames || frames.length === 0) return;

  const maxIndex = max(0, frames.length - 1);

  if (!indexSlider) {
    indexSlider = createSlider(0, maxIndex, currentIndex, 1);
    indexSlider.style("width", SLIDER_WIDTH + "px");
    indexSlider.input(() => {
      const v = floor(indexSlider.value());
      if (frames.length > 0) {
        currentIndex = constrain(v, 0, frames.length - 1);
      }
    });
  } else {
    indexSlider.elt.min = 0;
    indexSlider.elt.max = maxIndex;
    indexSlider.value(currentIndex);
  }

  positionSlider();
}

function positionSlider() {
  if (!indexSlider) return;
  const x = (windowWidth - SLIDER_WIDTH) / 2;
  const y = windowHeight - 50;
  indexSlider.position(x, y);
}

function syncSliderToIndex() {
  if (!indexSlider || !frames || frames.length === 0) return;
  indexSlider.value(currentIndex);
}

// build frames from CSV
function buildFrames() {
  frames = [];
  if (!table) return;

  const rowCount = table.getRowCount();
  for (let r = 0; r < rowCount; r++) {
    const row = table.getRow(r);
    const dateStr = getStringAny(row, ["date", "Date", "DATE"]);
    if (!dateStr) continue;

    const frame = {
  date: dateStr,
  idx: frames.length,

  cheeksDelta: getNumAny(row, [
    "cheek_delta",
    "cheekDelta",
    "cheek_fullness_delta",
    "cheek_delta_vs_avg",
    "cheek_delta_vs_mean"
  ], 0),

  darkDelta: getNumAny(row, [
    "dark_delta",
    "darkDelta",
    "dark_circles_delta",
    "dark_delta_vs_avg",
    "dark_circle_delta"
  ], 0),

  jawDelta: getNumAny(row, [
    "jaw_delta",
    "jawDelta",
    "jaw_width_delta",
    "jaw_delta_vs_avg",
    "jaw_line_delta"
  ], 0),

  weight: getNumAny(row, ["weight", "Weight"], NaN),
  bmi:    getNumAny(row, ["bmi", "BMI"], NaN),
  sleep:  getNumAny(row, ["sleep_hours", "Sleep", "sleep"], NaN),

  // hairFactor tries to follow the real face crop per image
  // 1. if CSV has a column like "hair_factor" / "hairDensity" / "hair_ratio", use that.
  // 2. else approximate from face height / index so it still changes over time.
  hairFactorRaw: getNumAny(row, ["hair_factor", "hairDensity", "hair_ratio"], NaN)
};

// post-compute hairFactor
let hf;
if (!isNaN(frame.hairFactorRaw)) {
  hf = frame.hairFactorRaw;
} else {
  const fh = getNumAny(row, ["face_height", "faceHeight"], 0.7);
  // taller face crop → usually more hair visible
  hf = map(fh, 0.4, 1.2, 0.7, 1.4, true);

  // tiny extra variation over time so years feel different even if fh is similar
  const tNorm = frames.length > 0 ? frame.idx / max(1, rowCount - 1) : 0;
  hf *= map(tNorm, 0, 1, 0.95, 1.05, true);
}
frame.hairFactor = constrain(hf, 0.3, 1.7);


    frames.push(frame);
  }

  if (frames.length > 0) {
    currentIndex = constrain(currentIndex, 0, frames.length - 1);
  }

  // if slider already exists (e.g. data reloaded), keep it in sync
  if (indexSlider) {
    setupSlider();
  }
}

function draw() {
  background(0, 0, 5);

  if (!frames || frames.length === 0) {
    fill(0, 0, 80);
    textAlign(CENTER, CENTER);
    text("No data frames loaded.", width / 2, height / 2);
    return;
  }

  const frame = frames[currentIndex];

  drawInfoPanel(frame);
  drawLegend();
  drawStrokeFace(frame, faceCX, faceCY, faceR);
}

// ---------- UI text ----------

function drawInfoPanel(f) {
  const pad = 12;
  const w = min(width * 0.55, 520);
  const h = 120;

  fill(0, 0, 10, 0.9);
  noStroke();
  rect(pad, pad, w, h, 10);

  fill(0, 0, 95);
  textAlign(LEFT, TOP);

  const lines = [];
  lines.push(
    "Date: " +
      f.date +
      "   Index: " +
      (f.idx + 1) +
      " / " +
      frames.length
  );

  let wStr = isNaN(f.weight) ? "n/a" : nf(f.weight, 1, 1) + " kg";
  let bmiStr = isNaN(f.bmi) ? "n/a" : nf(f.bmi, 1, 1);
  let sleepStr = isNaN(f.sleep)
    ? "sleep not logged"
    : nf(f.sleep, 1, 1) + " h (logged)";

  lines.push("Weight: " + wStr + "   BMI: " + bmiStr + "   Sleep: " + sleepStr);

  lines.push(
    "Jaw Δ: " +
      nf(f.jawDelta, 1, 3) +
      "   Cheek fullness Δ: " +
      nf(f.cheeksDelta, 1, 3) +
      "   Dark circles Δ: " +
      nf(f.darkDelta, 1, 3)
  );

  lines.push(
    "Interpretation: blue strokes → jaw line; red strokes → cheek fullness; " +
      "black strokes → dark-circle intensity."
  );

  let y = pad + 8;
  for (let i = 0; i < lines.length; i++) {
    text(lines[i], pad + 10, y);
    y += 18;
  }
}

function drawLegend() {
  const w = 260;
  const h = 110;
  const x = 16;
  const y = height - h - 80; // a bit above the slider

  fill(0, 0, 10, 0.9);
  noStroke();
  rect(x, y, w, h, 10);

  const r = 6;
  let cy = y + 18;

  textAlign(LEFT, CENTER);
  fill(0, 0, 95);
  text("Color legend (per stroke):", x + 12, cy);
  cy += 20;

  // jaw line
  fill(215, 70, 95);
  circle(x + 20, cy, r * 2);
  fill(0, 0, 95);
  text("Jaw line / jaw structure", x + 32, cy);
  cy += 18;

  // cheeks
  fill(10, 90, 95);
  circle(x + 20, cy, r * 2);
  fill(0, 0, 95);
  text("Cheek fullness", x + 32, cy);
  cy += 18;

  // dark circles
  fill(0, 0, 10);
  circle(x + 20, cy, r * 2);
  fill(0, 0, 95);
  text("Dark-circle intensity", x + 32, cy);
  cy += 18;

  fill(0, 0, 85);
  textSize(11);
  text(
    "Stroke density & length scale with change vs baseline.",
    x + 12,
    cy
  );
  textSize(13);
}

// ---------- core visualization: stroke-based face ----------

function drawStrokeFace(f, cx, cy, r) {
  push();

  const cheekNorm = constrain(f.cheeksDelta / 0.12, -1, 1);
  const darkNorm  = constrain(f.darkDelta   / 0.15, -1, 1);
  const jawNorm   = constrain(f.jawDelta    / 0.10, -1, 1);

  noStroke();
  fill(0, 0, 92, 0.7);
  const faceW = r * 0.9;
  const faceH = r * 1.25;
  ellipse(cx, cy, faceW, faceH);

  noFill();
  stroke(0, 0, 20, 0.9);
  strokeWeight(2);
  ellipse(cx, cy, faceW, faceH);

    // --- hair scribbles: quantity & length depend on this frame's hairFactor ---
  const hf = constrain(f.hairFactor || 1.0, 0.3, 1.7);

  const baseHairCount   = 180;
  const baseLenMin      = 6;
  const baseLenMax      = 18;

  const hairCount  = floor(baseHairCount * hf);                 // more hair → more strokes
  const hairLenMin = baseLenMin * (0.7 + 0.5 * hf);             // more hair → longer scribbles
  const hairLenMax = baseLenMax * (0.7 + 0.5 * hf);

  noiseSeed(1234 + f.idx);                                      // different pattern per frame
  strokeWeight(1.7 + 0.6 * hf);
  // slightly darker when there is *more* hair, lighter when there is less
  const hairBright = map(hf, 0.3, 1.7, 55, 30, true);
  stroke(30, 70, hairBright, 0.95);

  for (let i = 0; i < hairCount; i++) {
    const a = random(-PI, 0);
    const baseR = r * random(0.9, 1.4);
    const px = cx + cos(a) * baseR;
    const py = cy + sin(a) * baseR - r * 0.15;

    const len = random(hairLenMin, hairLenMax);
    const jitter = random(-0.3, 0.3);

    const px2 = px + cos(a + jitter) * len;
    const py2 = py + sin(a + jitter) * len;

    line(px, py, px2, py2);
  }


  // face strokes
  const strokeCount = 400;
  const t = frameCount * 0.01;

  for (let i = 0; i < strokeCount; i++) {
    let u, v;
    for (;;) {
      u = random(-1, 1);
      v = random(-1, 1);
      if (u * u + (v * 1.2) * (v * 1.2) <= 1) break;
    }

    const px = cx + u * (faceW * 0.48);
    const py = cy + v * (faceH * 0.52);

    let region = "neutral";
    if (v > 0.1) {
      region = "jaw";
    } else if (v > -0.05 && v <= 0.25 && abs(u) > 0.25) {
      region = "cheek";
    } else if (v <= -0.05 && v > -0.45) {
      region = "dark";
    }

    let sw = 1.4;
    let lenBase = 12;
    let colH = 0,
      colS = 0,
      colB = 80,
      alpha = 0.7;

    if (region === "jaw") {
      const mag = abs(jawNorm);
      colH = 215;
      colS = 70;
      colB = 95;
      alpha = 0.5 + 0.8 * mag;
      lenBase = 10 + 14 * mag;
      sw = 1.5 + 1.2 * mag;
    } else if (region === "cheek") {
      const mag = abs(cheekNorm);
      colH = 10;
      colS = 90;
      colB = 95;
      alpha = 0.4 + 0.8 * mag;
      lenBase = 8 + 12 * mag;
      sw = 1.4 + 0.8 * mag;
    } else if (region === "dark") {
      const mag = abs(darkNorm);
      colH = 0;
      colS = 0;
      colB = 18;
      alpha = 0.3 + 1.0 * mag;
      lenBase = 6 + 10 * mag;
      sw = 1.3 + 0.8 * mag;
    } else {
      colH = 0;
      colS = 0;
      colB = 70;
      alpha = 0.3;
      lenBase = 6;
      sw = 1;
    }

    stroke(colH, colS, colB, alpha);
    strokeWeight(sw);

    const ang = noise(px * 0.01, py * 0.01, t) * TWO_PI * 2.0;
    const len = lenBase * random(0.5, 1.2);

    const px2 = px + cos(ang) * len;
    const py2 = py + sin(ang) * len;
    line(px, py, px2, py2);
  }

  pop();
}

// ---------- navigation ----------

function keyPressed() {
  if (!frames || frames.length === 0) return;

  if (keyCode === RIGHT_ARROW) {
    currentIndex = (currentIndex + 1) % frames.length;
    syncSliderToIndex();
  } else if (keyCode === LEFT_ARROW) {
    currentIndex = (currentIndex - 1 + frames.length) % frames.length;
    syncSliderToIndex();
  }
}
