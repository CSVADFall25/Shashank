import json
import os
from datetime import datetime
from pathlib import Path

DATA_DIR = Path(__file__).parent
SELFIES_DIR = DATA_DIR / "selfies"
MANIFEST_PATH = DATA_DIR / "manifest.json"

def extract_date_from_filename(filename):
    """
    Expected formats:
      YYYY-MM-DD_HHMM.jpg
      YYYY-MM-DD_HHMM-1.jpg
      etc.

    If no valid date found → return empty string.
    """
    try:
        base = filename.split('.')[0]
        date_str = base.split('_')[0]
        datetime.strptime(date_str, "%Y-%m-%d")  # validate
        return date_str
    except:
        return ""

def main():
    print(f"Scanning {SELFIES_DIR}")

    entries = []
    for f in sorted(os.listdir(SELFIES_DIR)):
        if f.lower().endswith((".jpg", ".jpeg", ".png")):
            date = extract_date_from_filename(f)
            entries.append({
                "date": date,
                "file": f
            })

    print(f"Found {len(entries)} images")

    with open(MANIFEST_PATH, "w") as fp:
        json.dump(entries, fp, indent=2)

    print(f"✔ manifest.json rebuilt at: {MANIFEST_PATH}")

if __name__ == "__main__":
    main()
