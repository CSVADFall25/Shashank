import csv
from pathlib import Path
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"

FACE_PATH = DATA_DIR / "facemesh_with_change.csv"
BIO_PATH = DATA_DIR / "biometrics.csv"
MEALS_PATH = DATA_DIR / "meals.csv"
OUT_PATH = DATA_DIR / "facemesh_bio_diet.csv"

print("FACE_PATH:", FACE_PATH)
print("BIO_PATH: ", BIO_PATH)
print("MEALS_PATH:", MEALS_PATH)
print("OUT_PATH: ", OUT_PATH)

# ---------- Load base tables ----------
face = pd.read_csv(FACE_PATH)          # one (or more) rows per selfie
bio = pd.read_csv(BIO_PATH)            # one row per date
meals = pd.read_csv(MEALS_PATH)        # multiple rows per date

# Normalize date formats to YYYY-MM-DD strings
for df in (face, bio, meals):
    df["date"] = pd.to_datetime(df["date"]).dt.strftime("%Y-%m-%d")

# ---------- Aggregate meals by date ----------
fat_words = ["ghee", "butter", "cheese", "mozzarella", "fried", "oil",
             "cream", "pizza", "burger", "mayonnaise", "mayo",
             "paneer", "coconut milk", "curry"]
sugar_words = ["sugar", "dessert", "cake", "ice cream", "sweet",
               "syrup", "chocolate", "cookie", "brownie"]
caffeine_words = ["coffee", "caffeine", "matcha", "tea",
                  "espresso", "latte", "chai"]

def classify_day(day_df: pd.DataFrame) -> pd.Series:
    if day_df.empty:
        return pd.Series({
            "diet_total_portion": 0.0,
            "diet_fat_portion": 0.0,
            "diet_sugar_portion": 0.0,
            "diet_outside_portion": 0.0,
            "diet_caffeine_meals": 0,
            "diet_tags": ""
        })

    d = day_df.copy()
    d["portion_grams"] = d["portion_grams"].fillna(0.0)
    total = float(d["portion_grams"].sum())

    ing = d["ingredients_text"].fillna("").str.lower()
    notes = d["notes"].fillna("").str.lower()
    brand = d["brand_or_place"].fillna("").str.lower()

    def portion_for(words):
        mask = ing.apply(lambda s: any(w in s for w in words)) | \
               notes.apply(lambda s: any(w in s for w in words))
        return float(d.loc[mask, "portion_grams"].sum())

    fat_p = portion_for(fat_words)
    sugar_p = portion_for(sugar_words)
    caf_meals = int(
        (ing.apply(lambda s: any(w in s for w in caffeine_words)) |
         notes.apply(lambda s: any(w in s for w in caffeine_words))
         ).sum()
    )
    home_p = float(d.loc[brand == "home", "portion_grams"].sum())
    out_p = total - home_p

    tags = []
    if total > 0:
        if fat_p / total > 0.35:
            tags.append("high-fat")
        if sugar_p / total > 0.25:
            tags.append("high-sugar")
        if out_p / total > 0.5:
            tags.append("mostly-outside")
    if caf_meals > 0:
        tags.append("caffeine")

    return pd.Series({
        "diet_total_portion": total,
        "diet_fat_portion": fat_p,
        "diet_sugar_portion": sugar_p,
        "diet_outside_portion": out_p,
        "diet_caffeine_meals": caf_meals,
        "diet_tags": ", ".join(tags)
    })

meals_agg = meals.groupby("date").apply(classify_day).reset_index()

# Also compute fractions so p5 can use them:
for col in ["diet_fat_portion", "diet_sugar_portion", "diet_outside_portion"]:
    frac_name = col.replace("_portion", "_frac")
    meals_agg[frac_name] = meals_agg[col] / meals_agg["diet_total_portion"].replace(0, 1)

# ---------- Merge all three ----------
merged = face.merge(bio, on="date", how="left", suffixes=("", "_bio"))
merged = merged.merge(meals_agg, on="date", how="left", suffixes=("", "_meal"))

# Fill NAs in diet fields with safe defaults
for col in [
    "diet_total_portion", "diet_fat_portion", "diet_sugar_portion",
    "diet_outside_portion", "diet_caffeine_meals",
    "diet_fat_frac", "diet_sugar_frac", "diet_outside_frac"
]:
    if col in merged.columns:
        merged[col] = merged[col].fillna(0.0 if "meals" not in col else 0)

if "diet_tags" in merged.columns:
    merged["diet_tags"] = merged["diet_tags"].fillna("")

# NOTE: sleep_hours in biometrics is logged as 5.5 in your CSV,
# but you told us it actually varied between ~5–7 hours.
# We’ll keep the column as a *rough* indicator in the HUD,
# but the real nuance comes from your explanation in the write-up.

merged.to_csv(OUT_PATH, index=False)
print(f"✅ Wrote merged dataset with shape {merged.shape} to {OUT_PATH}")
