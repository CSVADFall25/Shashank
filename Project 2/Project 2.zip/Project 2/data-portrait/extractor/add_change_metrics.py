import csv
from pathlib import Path
import math

BASE_DIR = Path(__file__).resolve().parent
DATA_IN = BASE_DIR / "data" / "facemesh_metrics.csv"
DATA_OUT = BASE_DIR / "data" / "facemesh_with_change.csv"

print(f"Input:  {DATA_IN}")
print(f"Output: {DATA_OUT}")

rows = []
with DATA_IN.open("r", newline="") as f:
  reader = csv.DictReader(f)
  for row in reader:
    rows.append(row)

if not rows:
  raise SystemExit("No rows in facemesh_metrics.csv")

# --- Compute baselines ---
cheek_vals = []
dark_vals = []
jaw_vals = []

for row in rows:
  try:
    fh = float(row.get("face_height_norm", 0) or 0.0)
    mw = float(row.get("midface_width_norm", 0) or 0.0)
    cheek = float(row.get("cheek_fullness_index", 0) or 0.0)
    dark = float(row.get("dark_circle_mean", 0) or 0.0)
  except ValueError:
    continue

  if fh > 1e-6 and mw > 0:
    jaw_ratio = mw / fh
    jaw_vals.append(jaw_ratio)
  cheek_vals.append(cheek)
  dark_vals.append(dark)

def safe_mean(vals, fallback=0.0):
  return sum(vals) / len(vals) if vals else fallback

cheek_mean = safe_mean(cheek_vals, 0.0)
dark_mean = safe_mean(dark_vals, 0.0)
jaw_mean = safe_mean(jaw_vals, 1.0)

print(f"cheek_mean: {cheek_mean:.4f}")
print(f"dark_mean:  {dark_mean:.4f}")
print(f"jaw_mean:   {jaw_mean:.4f}")

# --- Write out new CSV with deltas ---
fieldnames = list(rows[0].keys()) + [
  "jaw_ratio",
  "cheek_delta",
  "dark_delta",
  "jaw_delta",
]

with DATA_OUT.open("w", newline="") as f:
  writer = csv.DictWriter(f, fieldnames=fieldnames)
  writer.writeheader()

  for row in rows:
    try:
      fh = float(row.get("face_height_norm", 0) or 0.0)
      mw = float(row.get("midface_width_norm", 0) or 0.0)
      cheek = float(row.get("cheek_fullness_index", 0) or 0.0)
      dark = float(row.get("dark_circle_mean", 0) or 0.0)
    except ValueError:
      fh = mw = cheek = dark = 0.0

    if fh > 1e-6 and mw > 0:
      jaw_ratio = mw / fh
    else:
      jaw_ratio = jaw_mean

    cheek_delta = cheek - cheek_mean
    dark_delta = dark - dark_mean
    jaw_delta = jaw_ratio - jaw_mean

    row_out = dict(row)
    row_out["jaw_ratio"] = f"{jaw_ratio:.6f}"
    row_out["cheek_delta"] = f"{cheek_delta:.6f}"
    row_out["dark_delta"] = f"{dark_delta:.6f}"
    row_out["jaw_delta"] = f"{jaw_delta:.6f}"

    writer.writerow(row_out)

print(f"✅ Wrote {len(rows)} rows with change metrics to {DATA_OUT}")
