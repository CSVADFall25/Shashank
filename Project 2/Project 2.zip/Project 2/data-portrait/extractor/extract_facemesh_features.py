import json
import csv
from pathlib import Path
import math

import cv2
import numpy as np
import mediapipe as mp

# ---------- Paths ----------
# This file lives in: data-portrait/extractor
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"           # <─ CHANGED
SELFIES_DIR = DATA_DIR / "selfies"
MANIFEST_PATH = DATA_DIR / "manifest.json"
OUT_CSV = DATA_DIR / "facemesh_metrics.csv"


print(f"BASE_DIR:      {BASE_DIR}")
print(f"DATA_DIR:      {DATA_DIR}")
print(f"SELFIES_DIR:   {SELFIES_DIR}")
print(f"MANIFEST_PATH: {MANIFEST_PATH}")

if not MANIFEST_PATH.exists():
    raise SystemExit(f"manifest.json not found at {MANIFEST_PATH}")

with MANIFEST_PATH.open("r") as f:
    manifest = json.load(f)

print(f"Loaded {len(manifest)} entries from manifest.json")

# ---------- Mediapipe FaceMesh ----------
mp_face_mesh = mp.solutions.face_mesh
face_mesh = mp_face_mesh.FaceMesh(
    static_image_mode=True,
    max_num_faces=1,
    refine_landmarks=True,
    min_detection_confidence=0.5,
)

# Indices from MediaPipe FaceMesh topology (approx):
IDX_FOREHEAD = 10
IDX_CHIN = 152
IDX_LEFT_CHEEK = 234
IDX_RIGHT_CHEEK = 454
IDX_LEFT_EYE_OUT = 33
IDX_LEFT_EYE_IN = 133
IDX_RIGHT_EYE_OUT = 263
IDX_RIGHT_EYE_IN = 362

def dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])

def landmark_xy(landmarks, idx, w, h):
    lm = landmarks[idx]
    return np.array([lm.x * w, lm.y * h], dtype=np.float32)

def sample_patch_mean(gray, center, size=12):
    """Sample mean intensity in a square patch around center (x,y)."""
    h, w = gray.shape
    cx, cy = int(center[0]), int(center[1])
    r = size // 2
    x0 = max(cx - r, 0)
    x1 = min(cx + r, w)
    y0 = max(cy - r, 0)
    y1 = min(cy + r, h)
    if x1 <= x0 or y1 <= y0:
        return float(gray.mean())
    patch = gray[y0:y1, x0:x1]
    return float(patch.mean())

rows = []

for i, entry in enumerate(manifest, start=1):
    file_name = entry.get("file")
    date = entry.get("date", "")

    img_path = SELFIES_DIR / file_name
    if not img_path.exists():
        print(f"[{i}] Missing file, skipping: {img_path}")
        continue

    img_bgr = cv2.imread(str(img_path))
    if img_bgr is None:
        print(f"[{i}] Could not read image, skipping: {img_path}")
        continue

    h, w, _ = img_bgr.shape
    img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)

    results = face_mesh.process(img_rgb)
    if not results.multi_face_landmarks:
        print(f"[{i}] No face landmarks found, skipping: {file_name}")
        continue

    face_landmarks = results.multi_face_landmarks[0].landmark

    # ----- Face proportions -----
    p_forehead = landmark_xy(face_landmarks, IDX_FOREHEAD, w, h)
    p_chin     = landmark_xy(face_landmarks, IDX_CHIN, w, h)
    p_l_cheek  = landmark_xy(face_landmarks, IDX_LEFT_CHEEK, w, h)
    p_r_cheek  = landmark_xy(face_landmarks, IDX_RIGHT_CHEEK, w, h)

    face_height_px = dist(p_forehead, p_chin)
    midface_width_px = dist(p_l_cheek, p_r_cheek)

    face_height_norm = face_height_px / float(h)
    midface_width_norm = midface_width_px / float(w)
    cheek_fullness_index = (
        midface_width_norm / face_height_norm if face_height_norm > 1e-6 else 0.0
    )

    # ----- Under-eye dark circles -----
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)

    # Left eye center
    p_le_out = landmark_xy(face_landmarks, IDX_LEFT_EYE_OUT, w, h)
    p_le_in  = landmark_xy(face_landmarks, IDX_LEFT_EYE_IN,  w, h)
    p_le_center = (p_le_out + p_le_in) / 2.0

    # Right eye center
    p_re_out = landmark_xy(face_landmarks, IDX_RIGHT_EYE_OUT, w, h)
    p_re_in  = landmark_xy(face_landmarks, IDX_RIGHT_EYE_IN,  w, h)
    p_re_center = (p_re_out + p_re_in) / 2.0

    # vertical offset for above/below sampling relative to face height
    v_off = 0.05 * face_height_px

    # left eye patches
    p_le_above = p_le_center + np.array([0, -v_off])
    p_le_below = p_le_center + np.array([0,  v_off])

    # right eye patches
    p_re_above = p_re_center + np.array([0, -v_off])
    p_re_below = p_re_center + np.array([0,  v_off])

    left_above  = sample_patch_mean(gray, p_le_above)
    left_below  = sample_patch_mean(gray, p_le_below)
    right_above = sample_patch_mean(gray, p_re_above)
    right_below = sample_patch_mean(gray, p_re_below)

    dark_circle_left  = left_above  - left_below
    dark_circle_right = right_above - right_below
    dark_circle_mean  = 0.5 * (dark_circle_left + dark_circle_right)

    # ----- Hair height / hairstyle-ish metric -----
    # Distance from top of image (y=0) to forehead point, normalized by face height
    hair_height_norm = (p_forehead[1]) / face_height_px if face_height_px > 1e-6 else 0.0

    rows.append(
        {
            "date": date,
            "file": file_name,
            "img_width": w,
            "img_height": h,
            "face_height_norm": face_height_norm,
            "midface_width_norm": midface_width_norm,
            "cheek_fullness_index": cheek_fullness_index,
            "dark_circle_left": dark_circle_left,
            "dark_circle_right": dark_circle_right,
            "dark_circle_mean": dark_circle_mean,
            "hair_height_norm": hair_height_norm,
        }
    )

    if i % 20 == 0:
        print(f"Processed {i} images...")

# ---------- Write CSV ----------
fieldnames = [
    "date",
    "file",
    "img_width",
    "img_height",
    "face_height_norm",
    "midface_width_norm",
    "cheek_fullness_index",
    "dark_circle_left",
    "dark_circle_right",
    "dark_circle_mean",
    "hair_height_norm",
]

OUT_CSV.parent.mkdir(parents=True, exist_ok=True)
with OUT_CSV.open("w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(rows)

print(f"\n✅ Wrote {len(rows)} rows to {OUT_CSV}")
