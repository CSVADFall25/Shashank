import cv2
import numpy as np
from pathlib import Path

ROOT = Path(__file__).resolve().parent
INPUT_DIR = ROOT / "extractor" / "data" / "selfies_raw"
OUTPUT_DIR = ROOT / "extractor" / "data" / "selfies"
TARGET_SIZE = 512
MARGIN = 0.35
EXTS = {".jpg", ".jpeg", ".png", ".JPG", ".JPEG", ".PNG"}

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
for fp in OUTPUT_DIR.iterdir():
    if fp.suffix in EXTS:
        print(f"Removing old crop: {fp.name}")
        fp.unlink()

face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)
eye_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_eye.xml"
)

def detect_face(gray):
    faces = face_cascade.detectMultiScale(
        gray, scaleFactor=1.1, minNeighbors=5, minSize=(80, 80)
    )
    if len(faces) == 0:
        return None
    return max(faces, key=lambda f: f[2] * f[3])  # biggest

def detect_eyes(gray, face_roi):
    x, y, w, h = face_roi
    roi = gray[y:y+h, x:x+w]
    eyes = eye_cascade.detectMultiScale(
        roi, scaleFactor=1.1, minNeighbors=4, minSize=(20, 20)
    )
    if len(eyes) < 2:
        return None
    eyes = sorted(eyes, key=lambda e: e[0])[:2]
    centers = []
    for ex, ey, ew, eh in eyes:
        cx = x + ex + ew // 2
        cy = y + ey + eh // 2
        centers.append((cx, cy))
    return centers

def align_by_eyes(img, gray, face_roi):
    eyes = detect_eyes(gray, face_roi)
    if not eyes or len(eyes) < 2:
        return img
    (x1, y1), (x2, y2) = eyes
    if x2 < x1:
        (x1, y1), (x2, y2) = (x2, y2), (x1, y1)
    dx, dy = x2 - x1, y2 - y1
    angle = np.degrees(np.arctan2(dy, dx))
    center = ((x1 + x2) / 2.0, (y1 + y2) / 2.0)
    M = cv2.getRotationMatrix2D(center, -angle, 1.0)
    h, w = img.shape[:2]
    return cv2.warpAffine(
        img, M, (w, h),
        flags=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_REFLECT_101
    )

def crop_face(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    face = detect_face(gray)
    if face is None:
        return None
    x, y, w, h = face

    aligned = align_by_eyes(img, gray, face)
    gray2 = cv2.cvtColor(aligned, cv2.COLOR_BGR2GRAY)
    face2 = detect_face(gray2)
    if face2 is not None:
        x, y, w, h = face2

    cx = x + w / 2.0
    cy = y + h / 2.0
    side = max(w, h) * (1 + MARGIN)

    x0 = int(max(cx - side / 2.0, 0))
    y0 = int(max(cy - side / 2.0, 0))
    x1 = int(min(cx + side / 2.0, aligned.shape[1]))
    y1 = int(min(cy + side / 2.0, aligned.shape[0]))
    if x1 <= x0 or y1 <= y0:
        return None

    crop = aligned[y0:y1, x0:x1]
    if crop.size == 0:
        return None

    ch, cw = crop.shape[:2]
    size = max(ch, cw)
    pad_y = (size - ch) // 2
    pad_x = (size - cw) // 2
    crop_sq = cv2.copyMakeBorder(
        crop,
        pad_y, size - ch - pad_y,
        pad_x, size - cw - pad_x,
        cv2.BORDER_REFLECT_101
    )
    return cv2.resize(
        crop_sq, (TARGET_SIZE, TARGET_SIZE),
        interpolation=cv2.INTER_AREA
    )

def fallback_center_crop(img):
    h, w = img.shape[:2]
    side = min(h, w)
    x0 = (w - side) // 2
    y0 = (h - side) // 2
    crop = img[y0:y0+side, x0:x0+side]
    return cv2.resize(crop, (TARGET_SIZE, TARGET_SIZE), interpolation=cv2.INTER_AREA)

def main():
    files = sorted(p for p in INPUT_DIR.iterdir() if p.suffix in EXTS)
    if not files:
        print(f"No images found in {INPUT_DIR}")
        return

    print(f"Found {len(files)} images in {INPUT_DIR}")
    for src in files:
        img = cv2.imread(str(src))
        if img is None:
            print(f"❌ Could not read {src.name}, skipping.")
            continue
        print(f"Processing {src.name} ...", end='', flush=True)
        cropped = crop_face(img)
        if cropped is None:
            print(" fallback center crop.")
            cropped = fallback_center_crop(img)
        else:
            print(" OK")
        out_path = OUTPUT_DIR / src.name
        cv2.imwrite(str(out_path), cropped)

    print("\n✅ Done. Faces written to:", OUTPUT_DIR)

if __name__ == "__main__":
    main()
